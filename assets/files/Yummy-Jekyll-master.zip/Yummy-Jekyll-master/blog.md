---
layout: page
title: All My Blogs
subtitle: <span class="mega-octicon octicon-clippy"></span>&nbsp;&nbsp; Take notes about everything new
menu: blog
css: ['blog-page.css']
---
{% include blog-page.html %}